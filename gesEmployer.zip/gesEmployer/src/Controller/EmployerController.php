<?php

namespace App\Controller;

use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;

use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;

use App\Entity\Service;
use App\Entity\Employer2;

class EmployerController extends Controller
{
    /**
     * @Route("/",name="employer_liste")
     * Method({"GET"})
     */

    public function index()
    {
        $employer = $this->getDoctrine()->getRepository(Employer2::class)->findAll();
        return $this->render('employer/index.html.twig', array('employer' => $employer));
    }

    /**
     * @Route("/employer/edit/{id}",name="edit_employer");
     * Method({"GET","POST"})
     */
    public function edit(Request $request, $id)
    {
        $employer = new Employer2();
        $employer = $this->getDoctrine()->getRepository(Employer2::class)->find($id);
        $form = $this->createFormBuilder($employer)
            ->add('matricule', TextType::class, array('attr' =>
            array('class' => 'form-control')))
            ->add('nomComplet', TextType::class, array('attr' =>
            array('class' => 'form-control')))
            ->add('datenais', DateType::class, ['attr' => ['class' => 'form-control']])
            ->add('service', EntityType::class, [
                'attr' => ['class' => 'form-control'],
                'class' => 'App\Entity\Service',
                'choice_label' => 'libelle',
                'expanded' => false,
                'multiple' => false
            ])
            ->add('salaire', IntegerType::class, ['attr' => ['class' => 'form-control']])
            ->add('save', SubmitType::class, array(
                'label' => 'Ajouter',
                'attr' => array('class' => 'btn btn-primary mt-3')
            ))
            ->getForm();

        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->flush();

            return $this->redirectToRoute('employer_liste');
        }
        return $this->render('employer/edit.html.twig', array(
            'form' => $form->createView()
        ));
    }

    /**
     * @Route("/employer/ajout",name="employer_ajout")
     * Method({"GET","POST"})
     */
    public function ajout(Request $request)
    {
        $employer = new Employer2();
        $form = $this->createFormBuilder($employer)
            ->add('matricule', TextType::class, array('attr' =>
            array('class' => 'form-control')))
            ->add('nomComplet', TextType::class, array('attr' =>
            array('class' => 'form-control')))
            ->add('datenais', DateType::class, ['attr' => ['class' => 'form-control']])
            ->add('service', EntityType::class, [
                'attr' => ['class' => 'form-control'],
                'class' => 'App\Entity\Service',
                'choice_label' => 'libelle',
                'expanded' => false,
                'multiple' => false
            ])
            ->add('salaire', IntegerType::class, ['attr' => ['class' => 'form-control']])
            ->add('save', SubmitType::class, array(
                'label' => 'Ajouter',
                'attr' => array('class' => 'btn btn-primary mt-3')
            ))
            ->getForm();

        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $employer = $form->getData();

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($employer);
            $entityManager->flush();

            return $this->redirectToRoute('employer_liste');
        }
        return $this->render('employer/ajout.html.twig', array(
            'form' => $form->createView()
        ));
    }



    /**
     * @Route("/employer/{id}",name="employer_show")
     */
    public function infoEmp($id)
    {
        $employer = $this->getDoctrine()->getRepository(Employer2::class)->find($id);

        return $this->render("employer/show.html.twig", array('employer' => $employer));
    }

    /**
     * @Route("/employer/delete/{id}")
     * Method({"DELETE"})
     */
    public function delete(Request $request, $id)
    {
        $employer = $this->getDoctrine()->getRepository(Employer2::class)->find($id);

        $entityManager = $this->getDoctrine()->getManager();
        $entityManager->remove($employer);
        $entityManager->flush();

        $response = new Response();
        $response->send();
    }








    /*public function index()
    {
        //return new Response('<html><body>Yahya</body></html>');
        return $this->render('employer/index.html.twig');
    }
    */
}
