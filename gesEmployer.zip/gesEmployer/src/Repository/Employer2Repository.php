<?php

namespace App\Repository;

use App\Entity\Employer2;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * @method Employer2|null find($id, $lockMode = null, $lockVersion = null)
 * @method Employer2|null findOneBy(array $criteria, array $orderBy = null)
 * @method Employer2[]    findAll()
 * @method Employer2[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class Employer2Repository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, Employer2::class);
    }

    // /**
    //  * @return Employer2[] Returns an array of Employer2 objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('e')
            ->andWhere('e.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('e.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Employer2
    {
        return $this->createQueryBuilder('e')
            ->andWhere('e.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
