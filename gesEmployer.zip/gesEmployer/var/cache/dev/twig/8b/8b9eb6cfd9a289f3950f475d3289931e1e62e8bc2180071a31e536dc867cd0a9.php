<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* employer/show.html.twig */
class __TwigTemplate_60a0da7e80cf6618abc17d1b28271bd8d1960a3b47727396736864321e4b74a5 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "employer/show.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "employer/show.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Crud étudiants";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <p> <span style=\"color:red;font-family:20px;font-weight:bolder\">Infos employer:</span> ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["employer"]) || array_key_exists("employer", $context) ? $context["employer"] : (function () { throw new RuntimeError('Variable "employer" does not exist.', 4, $this->source); })()), "nomComplet", [], "any", false, false, false, 4), "html", null, true);
        echo " est né le ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["employer"]) || array_key_exists("employer", $context) ? $context["employer"] : (function () { throw new RuntimeError('Variable "employer" does not exist.', 4, $this->source); })()), "datenais", [], "any", false, false, false, 4), "d-m-Y H:i:s"), "html", null, true);
        echo ".Son salaire est ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["employer"]) || array_key_exists("employer", $context) ? $context["employer"] : (function () { throw new RuntimeError('Variable "employer" does not exist.', 4, $this->source); })()), "salaire", [], "any", false, false, false, 4), "html", null, true);
        echo " </p>
    <hr>
    <a href=\"/\">Go back</a>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "employer/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 4,  66 => 3,  53 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block title %}Crud étudiants{% endblock %}
{% block body %}
    <p> <span style=\"color:red;font-family:20px;font-weight:bolder\">Infos employer:</span> {{employer.nomComplet}} est né le {{employer.datenais|date('d-m-Y H:i:s')}}.Son salaire est {{employer.salaire}} </p>
    <hr>
    <a href=\"/\">Go back</a>
{% endblock %}", "employer/show.html.twig", "/home/yahya/Documents/symfoni/gesEmployer/templates/employer/show.html.twig");
    }
}
