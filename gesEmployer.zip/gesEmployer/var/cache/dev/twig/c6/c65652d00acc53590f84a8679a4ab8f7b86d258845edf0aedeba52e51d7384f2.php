<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* employer/index.html.twig */
class __TwigTemplate_a618b1a11953d3c725327d1dfc3d7209939d1352cedfbc6fba007146dcdaafa9 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "employer/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "employer/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Employer";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Liste des employers</h1>
    ";
        // line 5
        if ((isset($context["employer"]) || array_key_exists("employer", $context) ? $context["employer"] : (function () { throw new RuntimeError('Variable "employer" does not exist.', 5, $this->source); })())) {
            // line 6
            echo "        <table id=\"employers\" class=\"table table-striped\">
            <thead>
                <tr>
                    <th>Matricule</th>
                    <th>Nom Complet</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                ";
            // line 15
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["employer"]);
            foreach ($context['_seq'] as $context["_key"] => $context["employer"]) {
                // line 16
                echo "                    <tr>
                        <td>";
                // line 17
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["employer"], "matricule", [], "any", false, false, false, 17), "html", null, true);
                echo "</td>
                        <td>";
                // line 18
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["employer"], "nomComplet", [], "any", false, false, false, 18), "html", null, true);
                echo "</td>
                        <td>
                            <a href=\"/employer/";
                // line 20
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["employer"], "id", [], "any", false, false, false, 20), "html", null, true);
                echo "\" class=\"btn btn-dark\">Voir</a>
                            <a href=\"/employer/edit/";
                // line 21
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["employer"], "id", [], "any", false, false, false, 21), "html", null, true);
                echo "\"class=\"btn btn-light\">Modifier</a>
                            <a href=\"#\" class=\"btn btn-danger delete-employer\" data-id=\"";
                // line 22
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["employer"], "id", [], "any", false, false, false, 22), "html", null, true);
                echo "\">Supprimer</a>
                        </td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['employer'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 26
            echo "            </tbody>
        </table>
    ";
        } else {
            // line 29
            echo "        <p>Y'a pas d'employers</p>    
    ";
        }
        // line 31
        echo "    
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 33
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 34
        echo "    <script src=\"/js/main.js\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "employer/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  148 => 34,  141 => 33,  133 => 31,  129 => 29,  124 => 26,  114 => 22,  110 => 21,  106 => 20,  101 => 18,  97 => 17,  94 => 16,  90 => 15,  79 => 6,  77 => 5,  74 => 4,  67 => 3,  54 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block title %}Employer{% endblock %}
{% block body %}
    <h1>Liste des employers</h1>
    {% if employer %}
        <table id=\"employers\" class=\"table table-striped\">
            <thead>
                <tr>
                    <th>Matricule</th>
                    <th>Nom Complet</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                {% for employer in employer %}
                    <tr>
                        <td>{{employer.matricule}}</td>
                        <td>{{employer.nomComplet}}</td>
                        <td>
                            <a href=\"/employer/{{employer.id}}\" class=\"btn btn-dark\">Voir</a>
                            <a href=\"/employer/edit/{{employer.id}}\"class=\"btn btn-light\">Modifier</a>
                            <a href=\"#\" class=\"btn btn-danger delete-employer\" data-id=\"{{employer.id}}\">Supprimer</a>
                        </td>
                    </tr>
                {% endfor %}
            </tbody>
        </table>
    {% else %}
        <p>Y'a pas d'employers</p>    
    {% endif %}
    
{% endblock %}
{% block javascripts %}
    <script src=\"/js/main.js\"></script>
{% endblock %}", "employer/index.html.twig", "/home/yahya/Documents/symfoni/gesEmployer/templates/employer/index.html.twig");
    }
}
