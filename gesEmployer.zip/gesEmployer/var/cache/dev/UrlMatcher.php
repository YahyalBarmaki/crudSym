<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/' => [[['_route' => 'employer_liste', '_controller' => 'App\\Controller\\EmployerController::index'], null, null, null, false, false, null]],
        '/employer/ajout' => [[['_route' => 'employer_ajout', '_controller' => 'App\\Controller\\EmployerController::ajout'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/employer/(?'
                    .'|edit/([^/]++)(*:68)'
                    .'|([^/]++)(*:83)'
                    .'|delete/([^/]++)(*:105)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_twig_error_test', '_controller' => 'twig.controller.preview_error::previewErrorPageAction', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        68 => [[['_route' => 'edit_employer', '_controller' => 'App\\Controller\\EmployerController::edit'], ['id'], null, null, false, true, null]],
        83 => [[['_route' => 'employer_show', '_controller' => 'App\\Controller\\EmployerController::infoEmp'], ['id'], null, null, false, true, null]],
        105 => [
            [['_route' => 'app_employer_delete', '_controller' => 'App\\Controller\\EmployerController::delete'], ['id'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
